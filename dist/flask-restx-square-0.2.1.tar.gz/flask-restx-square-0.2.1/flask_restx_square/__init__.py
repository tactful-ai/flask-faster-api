'''
Flask-restx-Squared
'''
__version__ = '0.1.0'

from .autowire_decorator import autowire, register_api
