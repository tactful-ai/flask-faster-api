# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flask_restx_square']

package_data = \
{'': ['*']}

install_requires = \
['flask-restx>=0.5.0,<0.6.0']

setup_kwargs = {
    'name': 'flask-restx-square',
    'version': '0.1.1',
    'description': 'Flask-RESTY is a Fast API style support for Flask. It Gives you MyPy types with the flexibility of flask.',
    'long_description': '==============\nFlask RESTY\n==============\n\n.. image:: https://img.shields.io/github/license/tactful-ai/flask-faster-api   \n    :alt: License\n    \n.. image:: https://img.shields.io/github/stars/tactful-ai/flask-faster-api?style=social   :alt: GitHub Repo stars\n\n.. image:: https://img.shields.io/pypi/pyversions/flaskresty   \n    :target: https://pypi.org/project/flaskresty\n    :alt: Supported Python versions\n\n\n\nFlask-RESTY is a Fast API style support for Flask. It Gives you MyPy types with the flexibility of flask.\n\n\n\nCompatibility\n=============\n\nFlask-RESTY requires Python 2.7 or 3.4+. \n\n\n\n\n\nInstallation\n============\n\nYou can install Flask-RESTY with pip:\n\n.. code-block:: console\n\n    $ pip install flaskresty\n    \n\nQuick start\n===========\n\nWith Flask-RESTY and the autowire decorator feature, parsing path parameters and creating api models is done using only one decorator! \n\n.. code-block:: python\n\n    from flask import Flask, jsonify, request\n    from flask_restx import Api, Resource, fields, marshal_with, reqparse\n    from typing import Dict, List, Optional, OrderedDict, get_type_hints\n    from flaskresty import autowire_decorator\n\n    app = Flask(__name__)\n\n\n    api = Api(app, version=\'1.0\', title=\'Courses API\')\n\n    autowire_decorator.register_api(api)\n\n\n    courses_ns = api.namespace(\'courses\', description=\'Courses Endpoints\')\n    course = api.model(\'Course\', {})\n\n    course_Model = dict({\n        \'id\': int,\n        \'title\': str,\n        \'duration\': int\n    })\n\n\n    class CourseDAO(object):\n        counter = 0\n        courses = [{\n            \'id\': 1,\n            \'title\': \'Python\',\n            \'duration\': 300}]\n\n        @ staticmethod\n        def get(id):\n            for course in CourseDAO.courses:\n                if course[\'id\'] == id:\n                    return course\n            api.abort(404, "Course {} doesn\'t exist".format(id))\n\n        @ staticmethod\n        def create(data):\n            course = data\n            course[\'id\'] = CourseDAO.counter = CourseDAO.counter + 1\n            CourseDAO.courses.append(course)\n            return course\n\n        @ staticmethod\n        def update(id, data):\n            course = CourseDAO.get(id)\n            course.update(data)\n            return course\n\n        @ staticmethod\n        def delete(id):\n            course = CourseDAO.get(id)\n            CourseDAO.courses.remove(course)\n\n\n        @ courses_ns.route(\'/<int:id>\')\n        class Course(Resource):\n            @ courses_ns.doc(\'get_course\')\n            @ autowire_decorator.autowire_decorator(\'/<int:id>\')\n            def get(self, id) -> course_Model:\n                course_data = CourseDAO.get(id)\n                return course_data\n\n\n\n        if __name__ == \'__main__\':\n            app.run(debug=True)\n\n\n\n\n\nContributors\n============\n\nFlask-RESTY is brought to you by @seifashraf1, @ahmedihabb2, @nadaabdelmaboud, @omargamal253\n\n\n\n\nContribution\n============\nWant to contribute? That\'s awesome! (Details Soon) \n',
    'author': 'nadaabdelmaboud',
    'author_email': 'nada5aled5@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
